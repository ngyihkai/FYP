# Revision History
* 2020.12.17
	* added support for Xilinx Vitis.
	* removed AlexNet.
  
* 2019.03.11
	* Update support for resnet-50.
    * Remove support for Xilinx.
    
* 2018.02.07
	* Update kernel and host programs to improve performance.
	* Add ImageNet classification Demo.

* 2017.10.14 
	* Add support for Xilinx's SDAccel tool (2017.02).
	
* 2017.09.10
	* Add sliding-window-based buffer in memRD to reduce DDR bandwidth.

* 2017.08.01
	* Changed to fixed-point pipeline.
	
* 2017.02.07
	* Add test vectors on Google's Drive and Baidu's Cloud Drive.
	
* 2016.11.07
	* Initial commit.
