rm -rf ./host/*.o ./host/*~ ./host/utility/*~ ./device/*~ ./*~
