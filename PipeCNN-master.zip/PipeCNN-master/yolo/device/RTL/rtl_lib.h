short mult_fix8b (char a_in, char b_in);
int   mult_add_fix8bx2 (char a0_in, char b0_in, char a1_in, char b1_in);
int   mult_add_fix8bx4 (char a0_in, char b0_in, char a1_in, char b1_in, char a2_in, char b2_in, char a3_in, char b3_in);